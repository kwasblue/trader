

class EventHandler():
    def __init__(self) -> None:
        pass